import numpy as np, pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import RidgeCV
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
OUT = "/home/claude/rnd/followup/results/"
f = pd.read_csv(OUT + "inventions_features.csv.gz"); o = pd.read_csv(OUT + "oracle_values.csv.gz"); o = o[o.eligible == 1]
df = o.merge(f.drop(columns=["m3_p"]), on=["run_id", "repeat", "budget", "cand"], how="inner"); df["state"] = df.run_id + "|" + df.budget.astype(str)
V = "V_q20_acc"; p = df.m3_p.values; yhat = (p >= .5).astype(int)
# consistency: oracle V equals counterfactual with the true label
df["V_true_cf"] = np.where(df.true_y == 1, df.A_Vtest1, df.A_Vtest0); df["V_other_cf"] = np.where(df.true_y == 1, df.A_Vtest0, df.A_Vtest1)
print("consistency |V_oracle - V(x,y_true)| max:", (df[V] - df.V_true_cf).abs().max())
# ---- invention scores
df["A_Iexp"] = p * df.A_I1 + (1 - p) * df.A_I0; df["A_Imax"] = df[["A_I0", "A_I1"]].max(1); df["A_Isurprise"] = np.where(yhat == 1, df.A_I0, df.A_I1); df["A_Iconfirm"] = np.where(yhat == 1, df.A_I1, df.A_I0)
df["A_dtau_exp"] = p * df.A_dtau1.abs() + (1 - p) * df.A_dtau0.abs(); df["A_dtau_max"] = df[["A_dtau0", "A_dtau1"]].abs().max(1)
df["A_pshift_exp"] = p * df.A_pool_pshift1 + (1 - p) * df.A_pool_pshift0; df["A_dls_exp"] = p * df.A_dls1 + (1 - p) * df.A_dls0
df["A_EpV_evalonly"] = p * df.A_Vtest1 + (1 - p) * df.A_Vtest0   # NOT allowed (uses test labels); diagnostic only
df["B_absbias05"] = df.B_bias05.abs(); df["B_absbias10"] = df.B_bias10.abs(); df["B_absbias_h"] = df.B_bias_h.abs()
pt = np.clip(p + df.B_bias05, 0, 1); df["B_corr_margin05"] = 1 - 2 * np.abs(pt - .5); pt2 = np.clip(p + df.B_bias_h, 0, 1); df["B_corr_margin_h"] = 1 - 2 * np.abs(pt2 - .5)
df["B_eI"] = df.B_e05 * df.A_Iexp; df["B_eI10"] = df.B_e10 * df.A_Iexp; df["B_ehI"] = df.B_eh * df.A_Iexp
df["C_DI"] = df.C_Dw * df.A_Iexp; df["C_DuI"] = df.C_Du * df.A_Iexp
SCORES = ["A_Iexp", "A_Imax", "A_Isurprise", "A_Iconfirm", "A_I0", "A_I1", "A_dtau_exp", "A_dtau_max", "A_pshift_exp", "A_dls_exp",
          "B_e05", "B_e10", "B_eh", "B_bias05", "B_bias_h", "B_absbias05", "B_absbias_h", "B_corr_margin05", "B_corr_margin_h", "B_eI", "B_eI10", "B_ehI",
          "C_Dw", "C_Du", "C_disprob", "C_DI", "C_DuI", "m3_margin", "A_EpV_evalonly"]
def topk(g, frac):
    k = max(1, int(np.ceil(frac * len(g)))); thr = np.sort(g[V].values)[::-1][k - 1]; return (g[V] >= thr) & (g[V] > 0)
df["top10"] = df.groupby("state", group_keys=False).apply(lambda g: topk(g, .10)); df["top5"] = df.groupby("state", group_keys=False).apply(lambda g: topk(g, .05))
rows = []
for s in SCORES:
    ps = []
    for st, g in df.groupby("state"):
        if g[V].nunique() < 2 or g[s].nunique() < 2: continue
        r = {"state": st, "repeat": g.repeat.iloc[0], "budget": g.budget.iloc[0], "rho": spearmanr(g[s], g[V])[0], "rho_margin": spearmanr(g[s], g.m3_margin)[0]}
        for k in ("top5", "top10"):
            if g[k].nunique() == 2:
                kk = int(g[k].sum()); r[f"auroc_{k}"] = roc_auc_score(g[k], g[s]); r[f"enrich_{k}"] = g.nlargest(kk, s)[k].mean() / g[k].mean()
        # V of the score's top-1 pick
        r["top1_V"] = g.loc[g[s].idxmax(), V]; ps.append(r)
    ps = pd.DataFrame(ps); blk = ps.groupby("repeat").rho.mean()
    rows.append({"score": s, "n_states": len(ps), "rho_median": ps.rho.median(), "rho_block_mean": blk.mean(), "rho_block_sd": blk.std(ddof=1), "frac_states_pos": (ps.rho > 0).mean(),
                 "rho_vs_margin_median": ps.rho_margin.median(), "auroc_top10": ps.auroc_top10.mean(), "enrich_top10": ps.enrich_top10.mean(), "enrich_top5": ps.enrich_top5.mean(), "mean_V_top1_pick": ps.top1_V.mean(),
                 **{f"rho_B{b}": ps[ps.budget == b].rho.mean() for b in (16, 24, 32, 40)}})
res = pd.DataFrame(rows).sort_values("rho_median", ascending=False); res.to_csv(OUT + "inventions_associations.csv", index=False)
pd.set_option("display.width", 260); print(res.round(3).to_string())
print("\nmean V of best candidate per state:", df.groupby("state")[V].max().mean().round(4), " margin top-1:", df[df.groupby("state").m3_margin.transform("max").eq(df.m3_margin)][V].mean().round(4))
# decomposition of the oracle value: label vs influence
print("\nDecomposition: corr(V_true, V_other) =", np.corrcoef(df.V_true_cf, df.V_other_cf)[0, 1].round(3), "; P(V_true>0 & V_other>0) =", ((df.V_true_cf > 0) & (df.V_other_cf > 0)).mean().round(4), "; P(V_true>0) =", (df.V_true_cf > 0).mean().round(4), "; P(V_true>0 & V_other<0)=", ((df.V_true_cf > 0) & (df.V_other_cf < 0)).mean().round(4))
print("Among candidates with V_true>0: share where the true label is the model's minority (surprise):", (df[df.V_true_cf > 0].true_y != yhat[df.V_true_cf > 0]).mean().round(3), "; overall surprise rate:", (df.true_y != yhat).mean().round(3))
print("Influence of the true label when V>0 vs V=0 vs V<0 (mean pool flips):", df.assign(I_true=np.where(df.true_y == 1, df.A_I1, df.A_I0)).groupby(np.sign(df.V_true_cf)).I_true.mean().round(2).to_dict())
# ---- cross-fitted predictors with new features (+ old allowed) leave-repeat-block-out
NEW = [s for s in SCORES if s not in ("m3_margin", "A_EpV_evalonly")]
OLD = ["logh", "abs_dist_thr", "in_band", "logVX", "logLS", "ST_z", "nn_revealed", "nn_revealed_kh", "nn_revealed_c", "pool_density_r05", "revealed_density_r05", "revealed_density_r10", "local_frac_kh", "local_label_entropy", "local_phys_conflict", "m3_p", "m3_margin", "m3_latent_v", "m3_pi_margin", "h_p", "abs_m3_minus_h", "abs_m3_minus_lr4", "abs_m3_minus_T", "T_tau_sd", "T_tv", "T_xsur2", "T_flips2", "cfg_main"]
for c in OLD + NEW: df[c] = df[c].fillna(df[c].median())
def crossfit(feats, name, mk):
    pred = np.full(len(df), np.nan)
    for r in sorted(df.repeat.unique()):
        tr = (df.repeat != r).values; te = ~tr; m = mk().fit(df.loc[tr, feats].values, df.loc[tr, V].values); pred[te] = m.predict(df.loc[te, feats].values)
    df[f"pred_{name}"] = pred; ps = []
    for st, g in df.groupby("state"):
        if g[V].nunique() < 2: continue
        r = {"repeat": g.repeat.iloc[0], "rho": spearmanr(g[f"pred_{name}"], g[V])[0], "top1_V": g.loc[g[f"pred_{name}"].idxmax(), V]}
        if g.top10.nunique() == 2: kk = int(g.top10.sum()); r["enrich10"] = g.nlargest(kk, f"pred_{name}").top10.mean() / g.top10.mean(); r["auroc10"] = roc_auc_score(g.top10, g[f"pred_{name}"])
        ps.append(r)
    ps = pd.DataFrame(ps); blk = ps.groupby("repeat").rho.mean(); r2 = 1 - np.nansum((df[V] - pred) ** 2) / np.sum((df[V] - df[V].mean()) ** 2)
    return {"model": name, "R2_oob": r2, "rho_median": ps.rho.median(), "rho_block_mean": blk.mean(), "rho_block_sd": blk.std(ddof=1), "frac_pos": (ps.rho > 0).mean(), "enrich_top10": ps.enrich10.mean(), "auroc_top10": ps.auroc10.mean(), "mean_V_top1": ps.top1_V.mean()}
cf = []
for feats, nm in ((NEW, "new_only"), (OLD + NEW, "old_plus_new")):
    cf.append(crossfit(feats, f"ridge_{nm}", lambda: make_pipeline(StandardScaler(), RidgeCV(alphas=np.logspace(-2, 3, 12)))))
    cf.append(crossfit(feats, f"gbm_{nm}", lambda: GradientBoostingRegressor(n_estimators=150, max_depth=2, learning_rate=0.05, subsample=0.8, random_state=0)))
cf = pd.DataFrame(cf); cf.to_csv(OUT + "inventions_crossfit.csv", index=False); print("\nCross-fitted (leave-repeat-block-out):"); print(cf.round(3).to_string())
df.to_csv(OUT + "inventions_merged.csv.gz", index=False)
