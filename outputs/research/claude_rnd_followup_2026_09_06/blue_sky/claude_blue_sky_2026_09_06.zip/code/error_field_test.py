"""Is the model's error field on unqueried points predictable label-blind?
For each state: LOO errors on revealed rows -> kernel error map e_hat(u) at unrevealed pool and test rows;
compare with the realised M3 errors at those rows (AUROC, Spearman). Also the model's own min(p,1-p)."""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/rnd")
from joblib import Parallel, delayed
from scipy.spatial import distance
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
from core import *
d = Data(); y = d.labels; lh = d.logh; x4 = d.x4
paths = pd.read_csv(REPO / "outputs/week9_phase1_14_m3_margin_acquisition/m3_margin_paths.csv.gz")
P1 = {r: g.sort_values("query_order").population_row_index.astype(int).tolist() for r, g in paths[paths.path.eq("P1")].groupby("run_id")}
def run(spec):
    tr = np.asarray(spec.train_indices); te = np.asarray(spec.test_indices); X4 = StandardScaler().fit(x4[tr]).transform(x4); rows = []
    for b in (16, 24, 32, 40):
        rev = np.asarray(P1[spec.run_id][:b]); m3 = M3(d, spec).fit(rev, b); cand = np.setdiff1d(tr, rev)
        p_loo = np.zeros(len(rev))
        for i in range(len(rev)):
            keep = np.delete(rev, i); p_loo[i] = y[keep].mean() if len(np.unique(y[keep])) < 2 else M3(d, spec).fit(keep, b).proba(np.array([rev[i]]))[0]
        e_loo = ((p_loo >= .5).astype(int) != y[rev]).astype(float); r_loo = y[rev] - p_loo
        for name, rows_idx in (("pool", cand), ("test", te)):
            pu = m3.proba(rows_idx); e_true = ((pu >= .5).astype(int) != y[rows_idx]).astype(int)
            Dm = distance.cdist(X4[rows_idx], X4[rev]); res = {"run_id": spec.run_id, "repeat": spec.repeat, "budget": b, "set": name, "n": len(rows_idx), "err_rate": e_true.mean(), "loo_err_rate": e_loo.mean()}
            for h in (0.5, 1.0, 2.0):
                W = np.exp(-0.5 * (Dm / h) ** 2); W /= np.maximum(W.sum(1, keepdims=True), 1e-12); eh = W @ e_loo; bh = W @ r_loo
                if e_true.sum() > 0 and e_true.sum() < len(e_true):
                    res[f"auroc_emap_h{h}"] = roc_auc_score(e_true, eh); res[f"auroc_absbias_h{h}"] = roc_auc_score(e_true, np.abs(bh))
                    pc = np.clip(pu + bh, 0, 1); res[f"auroc_corrmargin_h{h}"] = roc_auc_score(e_true, 1 - 2 * np.abs(pc - .5))
            if e_true.sum() > 0 and e_true.sum() < len(e_true):
                res["auroc_margin"] = roc_auc_score(e_true, 1 - 2 * np.abs(pu - .5))
            rows.append(res)
    return rows
if __name__ == "__main__":
    specs = [s for s in d.specs if s.fold == ((s.repeat - 1) % 5) + 1]
    out = Parallel(n_jobs=2, backend="multiprocessing")(delayed(run)(s) for s in specs)
    df = pd.DataFrame([r for rows in out for r in rows]); df.to_csv("/home/claude/rnd/followup/results/error_field_test.csv", index=False)
    pd.set_option("display.width", 250); print(df.groupby(["set", "budget"])[[c for c in df.columns if c.startswith("auroc") or c.endswith("rate")]].mean().round(3).to_string())
