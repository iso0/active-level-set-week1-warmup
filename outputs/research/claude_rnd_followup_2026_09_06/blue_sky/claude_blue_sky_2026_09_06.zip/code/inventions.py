"""Blue-sky round: three new label-blind valuations of an unqueried point, computed on the same
80 states (P1 prefixes, B in {16,24,32,40}, 20 runs) and eligible candidates as oracle_values.csv.gz.

A. Counterfactual Structural Influence (CSI): exact M3 refit with each hypothetical label y in {0,1}
   -> number of unrevealed-pool decision flips I_y(x); Stage-1 threshold shift dtau_y(x); ARD length/amp shift.
   Scores: I_exp = p I_1 + (1-p) I_0 ; I_max ; I_surprise = I_{1-yhat} ; |dtau|_exp ; and the
   evaluation-only counterfactual test values V(x,0), V(x,1) (to decompose the oracle value).
B. LOO meta-error map: leave-one-out M3 on the revealed set -> realised error indicators e_i and
   signed LOO residuals r_i = y_i - p_loo(x_i); kernel-smoothed at candidates:
   e(x) (local LOO error rate), bias(x) (signed), corrected probability p~ = clip(p + bias), and
   corrected margin 1-2|p~-0.5|; scores e(x), e(x)*I_exp, corrected margin, |bias|.
C. Structural-hypothesis committee: physics exponents (a,b) in {0.25,0.5,0.75}x{1,1.5,2} for
   h_ab = P/(VX^a LS^b); each hypothesis = Stage-1 logistic on log h_ab + same Stage-2 ARD GP;
   weights = normalised exp(Laplace log marginal likelihood); disagreement D(x) = weighted variance
   of decisions; also unweighted vote entropy; score D(x), D(x)*I_exp.
"""
import sys, math, time, json, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/rnd")
from joblib import Parallel, delayed
from scipy.spatial import distance
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from core import *

d = Data(); pop = d.population; y = d.labels; lh = d.logh; x4 = d.x4
band = (lh >= 20.3621) & (lh <= 21.2533)
paths = pd.read_csv(REPO / "outputs/week9_phase1_14_m3_margin_acquisition/m3_margin_paths.csv.gz")
P1 = {r: g.sort_values("query_order").population_row_index.astype(int).tolist() for r, g in paths[paths.path.eq("P1")].groupby("run_id")}
BUD = (16, 24, 32, 40)
EXPONENTS = [(a, b) for a in (0.25, 0.5, 0.75) for b in (1.0, 1.5, 2.0)]
logP, logV, logL = np.log(pop.P.to_numpy(float)), np.log(pop.VX.to_numpy(float)), np.log(pop.LS.to_numpy(float))


def q20acc(prob, te, fl):
    f = fl["B1_q20"]; return float(((prob[f] >= .5).astype(int) == y[te][f]).mean())


def stage1_threshold(fit):
    ph = fit.physics; thr = -ph.model.intercept_[0] / ph.model.coef_[0, 0]; return float(ph.scaler.inverse_transform([[thr]])[0, 0])


def fit_hypothesis(spec, rev, b, a, bexp):
    """M3 with alternative physics coordinate log h_ab (Stage-1) + same Stage-2; returns fit and lml."""
    lh_ab = logP - a * logV - bexp * logL
    physics = p11.fit_physics_mean(lh_ab, y, rev, p13.seed_u32("shared_physics", spec.run_id, b))
    fit = p13.fit_hybrid(x4, lh_ab, y, rev, spec.train_indices, physics, "M3", 100.0)
    return fit, lh_ab, float(fit.gp.log_marginal_likelihood_value_)


def run(spec):
    tr = np.asarray(spec.train_indices); te = np.asarray(spec.test_indices); fl = d.flags(spec)
    sc4 = StandardScaler().fit(x4[tr]); X4 = sc4.transform(x4); path = P1[spec.run_id]; rows = []
    for b in BUD:
        rev = np.asarray(path[:b]); m3 = M3(d, spec).fit(rev, b); base_fit = m3.fit_
        cand = np.setdiff1d(tr, rev); pc = m3.proba(cand); elig = cand[band[cand] | ((pc > 0.02) & (pc < 0.98))]
        base_pool_dec = (pc >= .5); base_te = m3.proba(te); base_q20 = q20acc(base_te, te, fl); thr0 = stage1_threshold(base_fit)
        ls0 = base_fit.length_scales; sd0 = base_fit.residual_sd
        # ---- B: LOO on revealed
        p_loo = np.zeros(len(rev))
        for i in range(len(rev)):
            keep = np.delete(rev, i)
            if len(np.unique(y[keep])) < 2: p_loo[i] = y[keep].mean(); continue
            mi = M3(d, spec).fit(keep, b); p_loo[i] = mi.proba(np.array([rev[i]]))[0]
        e_loo = ((p_loo >= .5).astype(int) != y[rev]).astype(float); r_loo = y[rev] - p_loo
        Dc = distance.cdist(X4[cand], X4[rev])
        def kern(h): w = np.exp(-0.5 * (Dc / h) ** 2); return w / np.maximum(w.sum(1, keepdims=True), 1e-12)
        W05, W10 = kern(0.5), kern(1.0)
        e_map05 = W05 @ e_loo; e_map10 = W10 @ e_loo; bias05 = W05 @ r_loo; bias10 = W10 @ r_loo
        Dh = np.abs(lh[cand][:, None] - lh[rev][None, :]); Wh = np.exp(-0.5 * (Dh / 0.15) ** 2); Wh = Wh / np.maximum(Wh.sum(1, keepdims=True), 1e-12)
        e_map_h = Wh @ e_loo; bias_h = Wh @ r_loo
        loo_err_rate = e_loo.mean()
        # ---- C: structural committee
        hyps = []
        for (a, bexp) in EXPONENTS:
            try:
                fit, lh_ab, lml = fit_hypothesis(spec, rev, b, a, bexp); comp = p13.components(fit, x4[cand], lh_ab[cand]); hyps.append((lml, comp["probability"]))
            except Exception:
                pass
        lmls = np.array([h[0] for h in hyps]); w = np.exp(lmls - lmls.max()); w /= w.sum(); P = np.array([h[1] for h in hyps])  # H x cand
        dec = (P >= .5).astype(float); pbar = (w[:, None] * dec).sum(0); D_w = pbar * (1 - pbar); pbar_u = dec.mean(0); D_u = pbar_u * (1 - pbar_u)
        Pw = (w[:, None] * P).sum(0); dis_prob = np.sqrt((w[:, None] * (P - Pw) ** 2).sum(0))
        # ---- A: counterfactual refits for eligible candidates
        cand_pos = {c: i for i, c in enumerate(cand)}
        for c in elig:
            i = cand_pos[c]; rec = {"run_id": spec.run_id, "repeat": spec.repeat, "budget": b, "cand": int(c), "m3_p": float(pc[i]),
                                   "B_e05": e_map05[i], "B_e10": e_map10[i], "B_eh": e_map_h[i], "B_bias05": bias05[i], "B_bias10": bias10[i], "B_bias_h": bias_h[i], "B_loo_err_rate": loo_err_rate,
                                   "C_Dw": D_w[i], "C_Du": D_u[i], "C_disprob": dis_prob[i], "C_n_hyp": len(hyps), "C_w_max": float(w.max())}
            rows.append(rec)
        # counterfactual refits with a modified label array (repository API takes the label array explicitly)
        for rec in [r for r in rows if r["budget"] == b]:
            c = rec["cand"]; i = cand_pos[c]; others = cand != c
            for lab in (0, 1):
                ylab = y.copy(); ylab[c] = lab
                physics = p11.fit_physics_mean(lh, ylab, np.r_[rev, c], p13.seed_u32("shared_physics", spec.run_id, b + 1))
                fit = p13.fit_hybrid(x4, lh, ylab, np.r_[rev, c], spec.train_indices, physics, "M3", 100.0)
                pp = p13.components(fit, x4[cand], lh[cand])["probability"]; pt = p13.components(fit, x4[te], lh[te])["probability"]
                rec[f"A_I{lab}"] = int(((pp >= .5) != base_pool_dec)[others].sum()); rec[f"A_dtau{lab}"] = stage1_threshold(fit) - thr0
                rec[f"A_dls{lab}"] = float(np.abs(np.log(fit.length_scales) - np.log(ls0)).sum()); rec[f"A_dsd{lab}"] = float(fit.residual_sd - sd0)
                rec[f"A_Vtest{lab}"] = q20acc(pt, te, fl) - base_q20; rec[f"A_pool_pshift{lab}"] = float(np.abs(pp - pc)[others].mean())
    return rows


if __name__ == "__main__":
    specs = [s for s in d.specs if s.fold == ((s.repeat - 1) % 5) + 1]
    t0 = time.time(); out = Parallel(n_jobs=2, verbose=5, backend="multiprocessing")(delayed(run)(s) for s in specs)
    df = pd.DataFrame([r for rows in out for r in rows]); df.to_csv("/home/claude/rnd/followup/results/inventions_features.csv.gz", index=False); print("elapsed", time.time() - t0, df.shape)
