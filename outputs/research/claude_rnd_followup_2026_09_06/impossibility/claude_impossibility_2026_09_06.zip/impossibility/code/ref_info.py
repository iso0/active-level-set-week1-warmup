"""Reference information rate under the strongest structural prior (Part 5 object).
For each of the 80 states, sample the monotone world posterior over the FULL pool (hard monotonicity, log h prior C=1,
revealed labels fixed) and compute for every eligible candidate x:
  iota_R(x)  = sum_{u in R} I(y_x ; y_u)            (bits about the 17 reference labels, pairwise)
  iota_F(x)  = sum_{u in F_{y_x}(x)} I(y_x ; y_u)   (bits about the rows the query would actually flip; true-label flip set)
  comp_R(x)  = number of reference rows comparable with x in the partial order
  I(y_x ; e-sign of V)  : mutual information between y_x and the sign of the world value of x (flip set fixed)
"""
import sys, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/rnd")
from core import *
from worlds import dominance, WorldSampler
OUT = "/home/claude/rnd/followup/results/"
d = Data(); pop = d.population; y = d.labels; lh = d.logh
DOM = dominance(pop.P.to_numpy(float), pop.VX.to_numpy(float), pop.LS.to_numpy(float))
paths = pd.read_csv(REPO / "outputs/week9_phase1_14_m3_margin_acquisition/m3_margin_paths.csv.gz")
P1 = {r: g.sort_values("query_order").population_row_index.astype(int).tolist() for r, g in paths[paths.path.eq("P1")].groupby("run_id")}
df = pd.read_csv(OUT + "twin_worlds_flips.csv.gz", keep_default_na=False); df["state"] = df.run_id + "|" + df.budget.astype(str)
L = lambda s: [int(t) for t in s.split(";")] if s else []
tv = df[df.lab == df.true_y].copy(); tv["F"] = tv.FR.map(L)
o = pd.read_csv(OUT + "oracle_values.csv.gz"); o = o[o.eligible == 1].copy(); o["state"] = o.run_id + "|" + o.budget.astype(str)


def mi(a, b):
    a = np.asarray(a, int); b = np.asarray(b, int); n = len(a); out = 0.0
    for va in (0, 1):
        for vb in (0, 1):
            pab = ((a == va) & (b == vb)).mean(); pa = (a == va).mean(); pb = (b == vb).mean()
            if pab > 0: out += pab * np.log2(pab / (pa * pb))
    return out


rows = []
for st, g in tv.groupby("state"):
    run_id, b = st.split("|"); b = int(b); spec = d.spec_by_id[run_id]; te = np.asarray(spec.test_indices); fl = d.flags(spec)
    R = np.where(fl["B1_q20"])[0]; Rrows = te[R]; rev = np.asarray(P1[run_id][:b])
    ws = WorldSampler(DOM, lh, lam=np.inf, prior="logh", C=1.0, seed=seed_u32("refinfo", st)).fit_prior(rev, y)
    S = ws.sample(rev, y, n_samples=300, burn=80, thin=2)
    m3 = M3(d, spec).fit(rev, b); dec = (m3.proba(te)[R] >= .5).astype(int)
    og = o[o.state == st]; xm = int(og.cand.values[np.lexsort((og.cand.values, -og.m3_margin.values))[0]]); xb = int(g.cand.values[np.argmax(g.V_R.values)])
    for r in g.itertuples():
        x = int(r.cand); Fpos = [list(R).index(u) for u in r.F]
        iR = sum(mi(S[:, x], S[:, u]) for u in Rrows); iF = sum(mi(S[:, x], S[:, Rrows[j]]) for j in Fpos)
        comp = int(DOM[x, Rrows].sum() + DOM[Rrows, x].sum())
        # world value sign of x with its realised flip set: V_w = -(1/17) sum_{u in F} (2*1[S_u == dec_u]-1)
        if Fpos:
            Vw = -(2 * (S[:, Rrows[Fpos]] == dec[Fpos][None, :]) - 1).sum(1); iV = mi(S[:, x], (Vw > 0).astype(int))
        else: iV = 0.0
        rows.append({"state": st, "repeat": spec.repeat, "budget": b, "cand": x, "is_margin": int(x == xm), "is_best": int(x == xb), "V_true": float(r.V_R), "k": len(Fpos), "pW_x": float(S[:, x].mean()),
                     "iota_R_bits": iR, "iota_F_bits": iF, "I_yx_signV_bits": iV, "comp_R": comp, "H_yx_bits": float(-sum(p * np.log2(p) for p in (S[:, x].mean(), 1 - S[:, x].mean()) if p > 0))})
    print(st, flush=True)
T = pd.DataFrame(rows); T.to_csv(OUT + "ref_info.csv.gz", index=False)
pd.set_option("display.width", 200)
print(T[["iota_R_bits", "iota_F_bits", "I_yx_signV_bits", "comp_R", "H_yx_bits"]].describe().round(4).to_string())
print("max iota_F per state (mean):", T.groupby("state").iota_F_bits.max().mean(), " margin pick iota_F:", T[T.is_margin == 1].iota_F_bits.mean(), " best iota_F:", T[T.is_best == 1].iota_F_bits.mean())
print("nonempty F only:", T[T.k > 0][["iota_F_bits", "I_yx_signV_bits"]].describe().round(4).to_string())
