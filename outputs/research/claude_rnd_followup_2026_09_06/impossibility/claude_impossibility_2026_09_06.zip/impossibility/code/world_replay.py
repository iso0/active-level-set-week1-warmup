"""Prospective replay of world-space acquisitions on the frozen outer runs (development data).

Arms (acquisition on the sampled monotone world posterior; M3 is the evaluation predictor on every path, and the
world-posterior classifier pW is evaluated as a second predictor on the same path):
  WH  : robust version-space halving        argmin |pW(x) - 1/2|
  WE  : expected marginal-entropy reduction over the unrevealed band (target set T)
  WM  : minimax number of still-uncertain target rows
  RND : seeded random path (baseline)
  P1  : the committed M3-margin path (incumbent; fixed path)
Usage: python world_replay.py ARM BMAX NRUNS [lam] [prior] [C] [tag]
"""
import sys, json, time, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/rnd")
from joblib import Parallel, delayed
from core import *
from worlds import dominance, WorldSampler, WorldAcquisition

ARM = sys.argv[1]; BMAX = int(sys.argv[2]); NRUNS = int(sys.argv[3])
LAM = float(sys.argv[4]) if len(sys.argv) > 4 else np.inf; PRIOR = sys.argv[5] if len(sys.argv) > 5 else "logh"; CREG = float(sys.argv[6]) if len(sys.argv) > 6 else 1.0
TAG = sys.argv[7] if len(sys.argv) > 7 else f"{ARM}_B{BMAX}_lam{LAM}_{PRIOR}_C{CREG}"
d = Data(); pop = d.population; y = d.labels; lh = d.logh
DOM = dominance(pop.P.to_numpy(float), pop.VX.to_numpy(float), pop.LS.to_numpy(float))
BAND = (lh >= 20.3621) & (lh <= 21.2533)
paths = pd.read_csv(REPO / "outputs/week9_phase1_14_m3_margin_acquisition/m3_margin_paths.csv.gz")
P1 = {r: g.sort_values("query_order").population_row_index.astype(int).tolist() for r, g in paths[paths.path.eq("P1")].groupby("run_id")}


def metrics_rows(prob, te, fl, spec, budget, model):
    out = []
    for subset, f in (("full81", np.ones(len(te), bool)), ("B1_q20", fl["B1_q20"]), ("B1_q30", fl["B1_q30"])):
        out.append({"run_id": spec.run_id, "repeat": spec.repeat, "fold": spec.fold, "arm": ARM, "model": model, "budget": budget, "subset": subset, **metric_values(y[te][f], prob[f])})
    return out


def run(spec):
    tr = np.asarray(spec.train_indices); te = np.asarray(spec.test_indices); fl = d.flags(spec)
    queried = list(map(int, (P1[spec.run_id] if ARM == "P1" else w85.initial_design(spec, pop))[:16]))
    ws = WorldSampler(DOM, lh, lam=LAM, prior=PRIOR, C=CREG, seed=seed_u32("worlds", spec.run_id, TAG)); rng = np.random.default_rng(seed_u32("rnd", spec.run_id))
    rows = []; steps = []
    for b in range(16, BMAX + 1):
        rev = np.asarray(queried); cands = np.setdiff1d(tr, rev)
        m3 = M3(d, spec).fit(rev, b); rows += metrics_rows(m3.proba(te), te, fl, spec, b, "M3")
        need_worlds = ARM in ("WH", "WE", "WM", "P1", "RND")
        if need_worlds:
            ws.fit_prior(rev, y); S = ws.sample(rev, y, n_samples=100, burn=60 if b == 16 else 20, thin=2)
            rows += metrics_rows(S.mean(0)[te], te, fl, spec, b, "W")
        if b == BMAX: break
        if ARM == "P1": nxt = int(P1[spec.run_id][b])
        elif ARM == "RND": nxt = int(rng.choice(cands))
        else:
            T = np.zeros(405, bool); T[BAND] = True; T[rev] = False
            wa = WorldAcquisition(S, T)
            sc = {"WH": wa.halving, "WE": wa.expected_entropy_reduction, "WM": wa.minimax_uncertain}[ARM](cands)
            # tie-break: halving score, then lowest index
            order = np.lexsort((cands, -wa.halving(cands), -np.asarray(sc, float))); nxt = int(cands[order[0]])
            pm = m3.proba(cands); steps.append({"run_id": spec.run_id, "budget": b, "selected": nxt, "pW": float(wa.pW[nxt]), "m3_p": float(pm[cands == nxt][0]), "margin_pick": int(margin_select(cands, pm)), "score": float(np.asarray(sc, float)[cands == nxt][0]), "n_uncertain_band": int(((wa.pW[T] > .1) & (wa.pW[T] < .9)).sum())})
        queried.append(nxt)
    return rows, steps, {"run_id": spec.run_id, "path": queried}


if __name__ == "__main__":
    specs = sorted(d.specs, key=lambda s: (s.repeat, s.fold))[:NRUNS]
    t0 = time.time(); out = Parallel(n_jobs=2, verbose=3, backend="multiprocessing")(delayed(run)(s) for s in specs)
    M = pd.DataFrame([r for o in out for r in o[0]]); M.to_csv(f"/home/claude/rnd/results/world_{TAG}_metrics.csv.gz", index=False)
    pd.DataFrame([r for o in out for r in o[1]]).to_csv(f"/home/claude/rnd/results/world_{TAG}_steps.csv.gz", index=False)
    json.dump([o[2] for o in out], open(f"/home/claude/rnd/results/world_{TAG}_paths.json", "w"))
    print("elapsed", time.time() - t0, M.shape)
