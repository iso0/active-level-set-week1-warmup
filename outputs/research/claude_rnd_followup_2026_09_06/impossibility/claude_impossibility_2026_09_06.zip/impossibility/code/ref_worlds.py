"""Exact enumeration of physically constrained reference-label worlds (theorem attack, Part 4).

For each of the 80 states: R = 17 Fold-B1-q20 rows.  Enumerate all 2^17 labelings of R, count monotone violations
(within R, and between R and the REVEALED labels; the frozen partial order), and weight by a label-blind prior:
  uniform over admissible worlds | log h logistic prior (C=1, fitted on revealed labels) | M3 marginals (independent).
For each candidate x (true label known -> realised flip set F on R, from twin_worlds_flips.csv.gz), the world value is
  V(x; w) = -(1/17) sum_{u in F} e_u(w),  e_u(w) = +1 if M3's current decision at u equals w_u else -1.
Outputs per state and violation budget v in {0,1,3,5,10,inf}: number of admissible worlds, effective number, P(margin
pick optimal), P(true oracle-best optimal), argmax entropy, P(V(x_m) >= V(x*)) (surviving twin mass), top-pair stability.
"""
import sys, json, numpy as np, pandas as pd
sys.path.insert(0, "/home/claude/rnd")
from core import *
from worlds import dominance
from sklearn.linear_model import LogisticRegression
OUT = "/home/claude/rnd/followup/results/"
d = Data(); pop = d.population; y = d.labels; lh = d.logh
DOM = dominance(pop.P.to_numpy(float), pop.VX.to_numpy(float), pop.LS.to_numpy(float))
paths = pd.read_csv(REPO / "outputs/week9_phase1_14_m3_margin_acquisition/m3_margin_paths.csv.gz")
P1 = {r: g.sort_values("query_order").population_row_index.astype(int).tolist() for r, g in paths[paths.path.eq("P1")].groupby("run_id")}
df = pd.read_csv(OUT + "twin_worlds_flips.csv.gz", keep_default_na=False); df["state"] = df.run_id + "|" + df.budget.astype(str)
L = lambda s: [int(t) for t in s.split(";")] if s else []
tv = df[df.lab == df.true_y].copy(); tv["F"] = tv.FR.map(L)
o = pd.read_csv(OUT + "oracle_values.csv.gz"); o = o[o.eligible == 1].copy(); o["state"] = o.run_id + "|" + o.budget.astype(str)
NR = 17; W = ((np.arange(2 ** NR)[:, None] >> np.arange(NR)[None, :]) & 1).astype(np.int8)   # 131072 x 17
BUDGETS_V = [0, 1, 3, 5, 10, np.inf]
rows = []
for st, g in tv.groupby("state"):
    run_id, b = st.split("|"); b = int(b); spec = d.spec_by_id[run_id]; te = np.asarray(spec.test_indices); fl = d.flags(spec)
    R = np.where(fl["B1_q20"])[0]; Rrows = te[R]; rev = np.asarray(P1[run_id][:b])
    m3 = M3(d, spec).fit(rev, b); p0 = m3.proba(te)[R]; dec = (p0 >= .5).astype(int)
    # violation counts
    within = np.zeros(2 ** NR, np.int32)
    for a in range(NR):
        for c in range(NR):
            if DOM[Rrows[a], Rrows[c]]: within += (W[:, a] == 1) & (W[:, c] == 0)
    c0 = np.array([int(((y[rev] == 0) & DOM[u, rev]).sum()) for u in Rrows])   # revealed C rows dominating u  -> violated if y_u = 1
    c1 = np.array([int(((y[rev] == 1) & DOM[rev, u]).sum()) for u in Rrows])   # revealed KH rows dominated by u -> violated if y_u = 0
    viol = within + W @ c0 + (1 - W) @ c1
    # priors
    z = (lh - lh[rev].mean()) / (lh[rev].std() + 1e-9)
    lr = LogisticRegression(C=1.0, max_iter=1000).fit(z[rev, None], y[rev]); ph = np.clip(lr.predict_proba(z[Rrows, None])[:, 1], 1e-4, 1 - 1e-4)
    logw_h = W @ np.log(ph) + (1 - W) @ np.log(1 - ph); pm = np.clip(p0, 1e-4, 1 - 1e-4); logw_m = W @ np.log(pm) + (1 - W) @ np.log(1 - pm)
    # candidate values on all worlds: V = -(1/17) sum_{u in F} e_u,  e_u = 2*1[W_u == dec_u]-1
    E = 2 * (W == dec[None, :]) - 1                                                   # 2^17 x 17
    cands = g.cand.values; Fmat = np.zeros((len(cands), NR));
    for i, F in enumerate(g.F):
        for u in F: Fmat[i, list(R).index(u)] = 1
    Vw = -(E @ Fmat.T) / NR                                                             # worlds x candidates
    Vtrue = g.V_R.values; og = o[o.state == st]; xm = int(og.cand.values[np.lexsort((og.cand.values, -og.m3_margin.values))[0]])
    im = int(np.where(cands == xm)[0][0]) if xm in set(cands) else None; ib = int(np.argmax(Vtrue))
    truth_world = int(sum(int(y[Rrows[a]]) << a for a in range(NR)))
    for v in BUDGETS_V:
        adm = viol <= v
        for pname, logw in (("uniform", np.zeros(2 ** NR)), ("logh", logw_h), ("m3", logw_m)):
            w = np.where(adm, np.exp(logw - logw[adm].max()), 0.0); w /= w.sum()
            n_adm = int(adm.sum()); eff = float(np.exp(-(w[w > 0] * np.log(w[w > 0])).sum()))
            Vmax = Vw.max(1, keepdims=True); opt = (Vw == Vmax)                              # ties share
            popt = (w[:, None] * opt / opt.sum(1, keepdims=True)).sum(0)                  # P(x optimal), ties shared
            Hopt = float(-(popt[popt > 0] * np.log(popt[popt > 0])).sum())
            rec = {"state": st, "repeat": spec.repeat, "budget": b, "v": v, "prior": pname, "n_adm": n_adm, "eff_n": eff, "truth_admissible": int(adm[truth_world]), "w_truth": float(w[truth_world]),
                   "P_best_true_optimal": float(popt[ib]), "H_argmax": Hopt, "max_P_optimal": float(popt.max()), "n_cand": len(cands),
                   "P_margin_optimal": float(popt[im]) if im is not None else np.nan,
                   "P_twin_margin_ge_best": float(w[Vw[:, im] >= Vw[:, ib]].sum()) if im is not None else np.nan,
                   "P_rank_best_over_margin": float(w[Vw[:, ib] > Vw[:, im]].sum()) if im is not None else np.nan,
                   "E_V_best": float((w * Vw[:, ib]).sum()), "E_V_margin": float((w * Vw[:, im]).sum()) if im is not None else np.nan,
                   "E_max_V": float((w * Vmax[:, 0]).sum()), "true_best_beats_margin": int(Vtrue[ib] > (Vtrue[im] if im is not None else 0)),
                   "world_Bayes_pick_V_true": float(Vtrue[int(np.argmax((w[:, None] * Vw).sum(0)))])}
            rows.append(rec)
    print(st, "adm(v=0)", int((viol <= 0).sum()), flush=True)
T = pd.DataFrame(rows); T.to_csv(OUT + "ref_worlds.csv", index=False)
pd.set_option("display.width", 250)
summ = T.groupby(["v", "prior"]).agg(n_adm=("n_adm", "median"), eff_n=("eff_n", "median"), truth_adm=("truth_admissible", "mean"), P_margin_opt=("P_margin_optimal", "mean"), P_best_opt=("P_best_true_optimal", "mean"), maxP=("max_P_optimal", "mean"), H=("H_argmax", "mean"), twin_mass=("P_twin_margin_ge_best", "mean"), EmaxV=("E_max_V", "mean"), wB_V=("world_Bayes_pick_V_true", "mean")).round(4)
print(summ.to_string())
