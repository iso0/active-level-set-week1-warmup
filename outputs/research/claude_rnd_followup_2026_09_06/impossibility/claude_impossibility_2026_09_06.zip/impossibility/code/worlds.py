"""Physics-constrained world space for the finite melt-pool pool.

A world is a complete binary labeling of the pool.  Structure used (all label-blind):
  * frozen monotone partial order  j >= i  iff  P_j>=P_i, VX_j<=VX_i, LS_j<=LS_i (one strict)   [Phase 1.19A]
    monotone world: y_i = 1  =>  y_j = 1 for all j >= i
  * violation penalty lam per violated comparable pair (lam = inf : hard monotone; finite : soft budget)
  * product prior on labels from a logistic in log h fitted on the REVEALED labels only ("learned prior"),
    or the uniform prior p = 1/2 (no log h information)
  * optional restriction of the world to the physical band / main configuration (rows outside are fixed
    by the prior's decision or left free)
Posterior over worlds  pi(y) ∝ prod_u p_u^{y_u}(1-p_u)^{1-y_u} · exp(-lam · #violations(y))  with revealed rows fixed.
Sampled by single-site Gibbs (the up-set lattice is connected under single flips, so the chain is irreducible for
finite lam; for lam=inf it is irreducible on monotone labelings consistent with the revealed labels when those are
themselves consistent).
"""
import numpy as np
from sklearn.linear_model import LogisticRegression


def dominance(P, VX, LS):
    X = np.c_[P, VX, LS]
    more = (X[None, :, 0] >= X[:, None, 0]) & (X[None, :, 1] <= X[:, None, 1]) & (X[None, :, 2] <= X[:, None, 2])
    strict = np.any(X[None, :, :] != X[:, None, :], axis=2)
    return more & strict          # DOM[i, j] = j dominates i (j is more keyhole-favouring)


class WorldSampler:
    def __init__(self, DOM, logh, lam=8.0, prior="logh", C=1.0, free_mask=None, seed=0):
        self.N = DOM.shape[0]; self.DOM = DOM; self.logh = np.asarray(logh, float); self.lam = float(lam); self.prior = prior; self.C = C
        self.up = [np.flatnonzero(DOM[i]) for i in range(self.N)]       # rows dominating i
        self.down = [np.flatnonzero(DOM[:, i]) for i in range(self.N)]  # rows dominated by i
        self.free_mask = np.ones(self.N, bool) if free_mask is None else np.asarray(free_mask, bool)
        self.rng = np.random.default_rng(seed); self.state = None

    def fit_prior(self, revealed, labels):
        rev = np.asarray(revealed, int); yl = np.asarray(labels, int)[rev]
        if self.prior == "uniform" or len(np.unique(yl)) < 2:
            self.p = np.full(self.N, 0.5); self.thr = np.median(self.logh[rev]); return self
        z = (self.logh - self.logh[rev].mean()) / (self.logh[rev].std() + 1e-9)
        lr = LogisticRegression(C=self.C, max_iter=1000).fit(z[rev, None], yl)
        self.p = np.clip(lr.predict_proba(z[:, None])[:, 1], 1e-4, 1 - 1e-4)
        self.thr = float(self.logh[rev].mean() - lr.intercept_[0] / lr.coef_[0, 0] * (self.logh[rev].std() + 1e-9))
        return self

    def _init_state(self, revealed, labels):
        y = (self.logh >= self.thr).astype(int)                       # threshold labeling in log h: monotone by construction
        y[revealed] = labels[revealed]
        return y

    def sample(self, revealed, labels, n_samples=100, burn=60, thin=2, warm=True):
        rev = np.asarray(revealed, int); labels = np.asarray(labels, int)
        fixed = np.zeros(self.N, bool); fixed[rev] = True
        free = np.flatnonzero(~fixed & self.free_mask)
        if self.state is None or not warm: y = self._init_state(rev, labels)
        else:
            y = self.state.copy(); y[rev] = labels[rev]
        # rows outside free_mask and not revealed: fixed at the prior decision
        out = ~fixed & ~self.free_mask; y[out] = (self.p[out] >= .5).astype(int)
        logit_p = np.log(self.p / (1 - self.p)); lam = self.lam
        samples = np.zeros((n_samples, self.N), np.int8); k = 0
        n_sweeps = burn + n_samples * thin
        for s in range(n_sweeps):
            for u in self.rng.permutation(free):
                n_up0 = int((y[self.up[u]] == 0).sum()) if len(self.up[u]) else 0
                n_dn1 = int((y[self.down[u]] == 1).sum()) if len(self.down[u]) else 0
                if np.isinf(lam):
                    if n_up0 and n_dn1: continue            # inconsistent neighbourhood: leave as is
                    y[u] = 0 if n_up0 else (1 if n_dn1 else int(self.rng.random() < self.p[u]))
                else:
                    lo = logit_p[u] - lam * (n_up0 - n_dn1)
                    y[u] = int(self.rng.random() < 1 / (1 + np.exp(-lo)))
            if s >= burn and (s - burn) % thin == 0:
                samples[k] = y; k += 1
        self.state = y.copy()
        return samples

    def violations(self, y):
        y = np.asarray(y, int); return int((self.DOM & (y[:, None] == 1) & (y[None, :] == 0)).sum())


def entropy(p):
    p = np.clip(p, 1e-9, 1 - 1e-9); return -(p * np.log(p) + (1 - p) * np.log(1 - p))


class WorldAcquisition:
    """Acquisitions on the sampled world posterior S (n_s x N, int8)."""
    def __init__(self, S, target_mask):
        self.S = S; self.pW = S.mean(0); self.T = np.asarray(target_mask, bool)

    def halving(self, cands):                           # A: most even split of the world posterior
        return -np.abs(self.pW[cands] - .5)

    def expected_entropy_reduction(self, cands, min_side=3):   # D: expected reduction of summed marginal entropy over the target set
        H0 = entropy(self.pW[self.T]).sum(); out = np.zeros(len(cands))
        for i, x in enumerate(cands):
            m1 = self.S[:, x] == 1; n1 = int(m1.sum()); n0 = len(m1) - n1
            if n1 < min_side or n0 < min_side: out[i] = 0.0; continue
            H1 = entropy(self.S[m1][:, self.T].mean(0)).sum(); Hz = entropy(self.S[~m1][:, self.T].mean(0)).sum()
            out[i] = H0 - (n1 * H1 + n0 * Hz) / len(m1)
        return out

    def minimax_uncertain(self, cands, delta=0.1, min_side=3):  # C: minimise worst-case number of still-uncertain target rows
        U0 = int(((self.pW[self.T] >= delta) & (self.pW[self.T] <= 1 - delta)).sum()); out = np.zeros(len(cands))
        for i, x in enumerate(cands):
            m1 = self.S[:, x] == 1; n1 = int(m1.sum()); n0 = len(m1) - n1
            if n1 < min_side or n0 < min_side: out[i] = -U0; continue
            worst = 0
            for m in (m1, ~m1):
                p = self.S[m][:, self.T].mean(0); worst = max(worst, int(((p >= delta) & (p <= 1 - delta)).sum()))
            out[i] = -worst
        return out
